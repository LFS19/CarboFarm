Owlready2 TODO list
===================

* Add support for property chain in entity.property.indirect()
* Add functions/methods for copying entities from an ontology to another
* Obtain individual property value inferred by HermiT

* Support additional file formats:
  * OWL/XML write
  * JSON
  * OBO
